I have finished the Project : Give Your Application Auto-Deploy Superpowers.
Please verify help me.